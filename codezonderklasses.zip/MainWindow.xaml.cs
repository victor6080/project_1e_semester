﻿using System;
using System.Collections.Generic;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace project_1e_semester
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        SerialPort _serialPort;
        byte[] _data;
        const int START_ADDRESS = 160;
        const int NUMBER_OF_DMX_BYTES = 513;
        DispatcherTimer _dispatcherTimer;
        int pan;
        int tilt;

        public MainWindow()
        {
            InitializeComponent();

            cbxPortName.Items.Add("None");
            foreach (string s in SerialPort.GetPortNames())
                cbxPortName.Items.Add(s);

            _serialPort = new SerialPort();
            _serialPort.BaudRate = 250000;
            _serialPort.StopBits = StopBits.Two;

            _data = new byte[NUMBER_OF_DMX_BYTES];

            _dispatcherTimer = new DispatcherTimer();
            _dispatcherTimer.Interval = TimeSpan.FromSeconds(0.1);
            _dispatcherTimer.Tick += _dispatcherTimer_Tick;
            _dispatcherTimer.Start();

        }

        private void SendDmxData(byte[] data, SerialPort serialPort)
        {
            data[0] = 0;

            if (serialPort != null && serialPort.IsOpen)
            {
                serialPort.BreakState = true;
                Thread.Sleep(1);
                serialPort.BreakState = false;
                Thread.Sleep(1);

                serialPort.Write(data, 0, data.Length);
            }
        }

        private void cbxPortName_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (_serialPort != null)
            {
                if (_serialPort.IsOpen)
                    _serialPort.Close();

                if (cbxPortName.SelectedItem.ToString() != "None")
                {
                    _serialPort.PortName = cbxPortName.SelectedItem.ToString();
                    _serialPort.Open();

                    sldrKleur.IsEnabled = true;
                    sldrSluiter.IsEnabled = true;
                    sldrGobo.IsEnabled = true;
                }
                else
                {
                    sldrKleur.IsEnabled = false;
                    sldrSluiter.IsEnabled = false;
                    sldrGobo.IsEnabled = false;
                }
            }
        }

        private void _dispatcherTimer_Tick(object? sender, EventArgs e)
        {
            SendDmxData(_data, _serialPort);
        }
        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            SendDmxData(new byte[NUMBER_OF_DMX_BYTES], _serialPort);
            _serialPort.Dispose();
        }
        
        private void KeyPress_KeyDown(object sender, KeyEventArgs e)
        {
            //pijltjes voor op en neer beweging
            if (e.Key == Key.Z & pan <= 254)
            {
                pan++;
            }
            if (e.Key == Key.S & pan >=1)
            {
                pan--;
            }
            _data[START_ADDRESS + 0] = Convert.ToByte(pan);
            lblpan.Content = pan;
            //pijltjes voor links rechts beweging
            if (e.Key == Key.D & tilt <= 254)
            {
                tilt++;
            }
            if (e.Key == Key.Q & tilt >= 1)
            {
                tilt--;
            }
            _data[START_ADDRESS + 1] = Convert.ToByte(tilt);
            lbltilt.Content = tilt;
        }

        private void sldr_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            //_data[START_ADDRESS + 0] = Convert.ToByte(pan);
            //lblpan.Content = pan;
            //_data[START_ADDRESS + 1] = Convert.ToByte(tilt);
            //lbltilt.Content = tilt;
            _data[START_ADDRESS + 2] = Convert.ToByte(sldrSluiter.Value);
            _data[START_ADDRESS + 3] = Convert.ToByte(sldrKleur.Value);
            _data[START_ADDRESS + 4] = Convert.ToByte(sldrGobo.Value);
        }
    }
}
